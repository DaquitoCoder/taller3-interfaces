let video = null;
let detector = null;
let detections = [];
let videoVisibility = true;
let detecting = false;

const videoAction = document.getElementById('videoAction');
const detectionAction = document.getElementById('detectionAction');
const modal = document.getElementById('modal');
const modalInstance = new bootstrap.Modal(modal);
const modalText = document.getElementById('modal-text');


function preload() {
  detector = ml5.objectDetector('cocossd');
}

function setup() {
  createCanvas(640, 480);
  video = createCapture(VIDEO);
  video.size(640, 480);
  video.hide();

  // Agrega un controlador de eventos para el evento 'loadedmetadata'
  video.elt.addEventListener('loadedmetadata', () => {
    console.log('Metadatos del video cargados');
    initDetection();
  });
}


function draw() {
  if (!video || !detecting) return;
  image(video, 0, 0);
  for (let i = 0; i < detections.length; i++) {
    drawResult(detections[i]);
  }
}

function drawResult(object) {
  boundingBox(object);
  drawLabel(object);
}

function boundingBox(object) {
  stroke('blue');
  strokeWeight(6);
  noFill();
  rect(object.x, object.y, object.width, object.height);
}

function drawLabel(object) {
  noStroke();
  fill('white');
  textSize(34);
  text(object.label, object.x + 15, object.y + 34);
}

function onDetected(error, results) {
  if (error) {
    console.error(error);
  }
  detections = results;
  if(detections.length > 0 && detections[0].label === 'person' && detections[0].confidence > 0.65) {
    console.log(detections[0])
    toggleDetecting();
    modalText.innerText = '¡Persona detectada!';
    modalInstance.show();
  }

  if (detecting) {
    detect();
  }
}

function detect() {
  detector.detect(video, onDetected);
}

function initDetection() {
  detector = ml5.objectDetector('cocossd', () => {
    console.log('Detector listo');
    toggleDetecting();
  });
}

function toggleVideo() {
  if (!video) return;
  if (videoVisibility) {
    video.hide();
    videoAction.innerText = 'Activar Video';
  } else {
    video.show();
    videoAction.innerText = 'Desactivar Video';
  }
  videoVisibility = !videoVisibility;
}

// function toggleDetecting() {
//   if (!video || !detector) return;
//   if (!detecting) {
//     detect();
//     video.hide();
//     detectionAction.innerText = 'Parar...';
//   } else {
//     detectionAction.innerText = 'Detectar Objetos';
//   }
//   detecting = !detecting;
// }

let detectionTimeout;

function toggleDetecting() {
  if (!video || !detector) return;
  if (!detecting) {
    detect();
    video.hide();
    detectionAction.innerText = 'Parar...';

    // Detener la detección después de 15 segundos
    detectionTimeout = setTimeout(() => {
      toggleDetecting();
    }, 10000);
    

  } else {
    clearTimeout(detectionTimeout); // Limpiar el temporizador si la detección se detiene manualmente
    detectionAction.innerText = 'Detectar Objetos';
  }
  detecting = !detecting;
}

